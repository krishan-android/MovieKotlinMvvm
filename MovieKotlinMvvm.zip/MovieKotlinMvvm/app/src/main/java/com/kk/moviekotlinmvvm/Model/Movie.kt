package com.kk.moviekotlinmvvm.Model

data class Movie(
    val name: String,
    val imageUrl: String,
    val category: String,
    val desc: String
)